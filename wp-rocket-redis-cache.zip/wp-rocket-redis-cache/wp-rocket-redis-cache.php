<?php
/**
 * Plugin Name: WP Rocket Redis Cache Extension
 * Description: Extiende WP Rocket para usar Redis como sistema de caché avanzada y realiza limpieza automática del caché.
 * Version: 1.1.1
 * Author: Roy3r
 * Text Domain: wp-rocket-redis
 * Domain Path: /languages
 */

defined( 'ABSPATH' ) || exit;

use WP_Rocket\Buffer\Cache;
use WP_Rocket\Buffer\Config;
use WP_Rocket\Buffer\Tests;

if ( ! class_exists( 'WP_Rocket_Redis_Cache' ) ) {

    class WP_Rocket_Redis_Cache extends Cache {

        protected $redis;
        protected $redis_prefix;

        public function __construct( Tests $tests, Config $config, array $options = [] ) {
            parent::__construct( $tests, $config, $options );

            try {
                $this->redis = new Redis();
                $this->redis->connect( '127.0.0.1', 6379 );
                // $this->redis->auth('tu_contraseña_redis');
            } catch (Exception $e) {
                error_log('Error al conectar con Redis: ' . $e->getMessage());
                $this->redis = null;
            }

            $site_prefix = is_multisite() ? get_current_blog_id() . '_' : '';
            $this->redis_prefix = 'wp_rocket_cache_' . $site_prefix;
        }

        protected function write_cache( $key, $value, $ttl ) {
            if ( ! $this->redis ) return false;
            $redis_key = $this->redis_prefix . $key;
            return $this->redis->setex( $redis_key, $ttl, $value );
        }

        protected function read_cache( $key ) {
            if ( ! $this->redis ) return false;
            $redis_key = $this->redis_prefix . $key;
            return $this->redis->get( $redis_key );
        }

        public function delete_cache( $key ) {
            if ( ! $this->redis ) return false;
            $redis_key = $this->redis_prefix . $key;
            return $this->redis->del( $redis_key );
        }
    }
}

add_action( 'plugins_loaded', function() {
    if ( ! class_exists( '\WP_Rocket\Buffer\Cache' ) ) {
        return;
    }

    $rocket_path        = WP_CONTENT_DIR . '/plugins/wp-rocket/';
    $rocket_config_path = WP_CONTENT_DIR . '/wp-rocket-config/';
    $rocket_cache_path  = WP_CONTENT_DIR . '/cache/wp-rocket/';

    $rocket_config_class = new Config([
        'config_dir_path' => $rocket_config_path,
    ]);

    $redis_cache = new WP_Rocket_Redis_Cache(
        new Tests( $rocket_config_class ),
        $rocket_config_class,
        [
            'cache_dir_path' => $rocket_cache_path,
        ]
    );

    $redis_cache->maybe_init_process();
}, 20);

// Limpieza automática al actualizar/borrar posts
function roy3r_clear_redis_cache_on_update( $post_id ) {
    if ( wp_is_post_revision( $post_id ) ) {
        return;
    }

    try {
        $redis = new Redis();
        $redis->connect( '127.0.0.1', 6379 );
    } catch (Exception $e) {
        error_log('Error al conectar con Redis: ' . $e->getMessage());
        return;
    }

    $url = get_permalink( $post_id );
    if ( $url ) {
        $url_parts = parse_url( $url );
        $key = 'wp_rocket_cache_' . md5( $url_parts['host'] . $url_parts['path'] );
        $redis->del( $key );
    }
}
add_action( 'save_post', 'roy3r_clear_redis_cache_on_update' );
add_action( 'deleted_post', 'roy3r_clear_redis_cache_on_update' );

// Limpiar toda la caché Redis desde el admin (requiere link manual)
add_action('admin_post_clear_all_redis_cache', function () {
    if ( current_user_can('manage_options') ) {
        try {
            $redis = new Redis();
            $redis->connect( '127.0.0.1', 6379 );
            $keys = $redis->keys('wp_rocket_cache_*');
            foreach ($keys as $key) {
                $redis->del($key);
            }
        } catch (Exception $e) {
            error_log('Error limpiando Redis: ' . $e->getMessage());
        }
        wp_redirect( admin_url() );
        exit;
    }
});
